from prac_code.plotter import Plotter
from prac_code.value import Value
from prac_code.tables import start


def main():
    print("Package __init__.py")


if __name__ == "__main__":
    main()
